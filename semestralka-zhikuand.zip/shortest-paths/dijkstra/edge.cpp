//
// Created by Andrei Zhikulin
//

#include "edge.hpp"

edge::edge(int source, int target, int weight) {
    this->source = source;
    this->target = target;
    this->weight = weight;
}
